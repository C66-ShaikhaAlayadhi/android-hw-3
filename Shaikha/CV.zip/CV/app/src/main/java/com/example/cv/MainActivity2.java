package com.example.cv;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;


public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        ImageButton Email= findViewById(R.id.imageButton2);
        ImageButton Call= findViewById(R.id.imageButton);
        final TextView NA = findViewById(R.id.textView6);
        TextView AG = findViewById(R.id.textView7);
        TextView JO = findViewById(R.id.textView8);
        TextView PH = findViewById(R.id.textView9);
        TextView EM = findViewById(R.id.textView10);

        Bundle S =getIntent().getExtras();
        String A = S.getString("name");
        String B = S.getString("age");
        String C = S.getString("job");
        String D = S.getString("phone");
        String E = S.getString("email");

        NA.setText(A);
        AG.setText(B);
        JO.setText(C);
        PH.setText(D);
        EM.setText(E);

        Button Back = findViewById(R.id.button2);

        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Y = new Intent(MainActivity2.this , MainActivity.class);
                startActivity(Y);
            }
        });

        Call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    String No = NA.getText().toString();
                    Uri number = Uri.parse("tel:"+ No);
                    Intent Z = new Intent(Intent.ACTION_DIAL, number);
                    startActivity(Z);
            }
        });

        Email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Y = new Intent(Intent.ACTION_VIEW);
                Y.setData(Uri.parse("abc@gmail.com"));
                Y.setClassName("com.google.android.gm", "com.google.android.gm.ComposeActivityGmail");
                Y.putExtra(Intent.EXTRA_CC, new String[]{"xyz@gmail.com"});
                Y.putExtra(Intent.EXTRA_BCC, new String[]{"pqr@gmail.com"});
                Y.putExtra(Intent.EXTRA_SUBJECT, "your subject goes here...");
                Y.putExtra(Intent.EXTRA_TEXT, "Your message content goes here...");

                startActivity(Y);
            }
        });


    }
}