package com.example.supercv;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class MajorActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_major);

        final EditText NAME = findViewById(R.id.editTextTextPersonName);
        final EditText AGE = findViewById(R.id.editTextNumber);
        final EditText NATIONALITY = findViewById(R.id.editTextTextPersonName2);

        final TextView dg = findViewById(R.id.textView11);
        final TextView eng = findViewById(R.id.eng);
        final TextView sci = findViewById(R.id.sci);
        final TextView art = findViewById(R.id.art);
        final TextView bus = findViewById(R.id.bus);
        final TextView la = findViewById(R.id.la);


        Bundle A =getIntent().getExtras();

        String AA = A.getString("degree");
        String BB = A.getString("eng");
        String CC = A.getString("sci");
        String DD = A.getString("art");
        String EE = A.getString("bus");
        String FF = A.getString("la");

        dg.setText(AA);
        eng.setText(BB);
        sci.setText(CC);
        art.setText(DD);
        bus.setText(EE);
        la.setText(FF);


        final Button next = findViewById(R.id.print_button);
//        final ImageButton add =findViewById(R.id.add);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String a = NAME.getText().toString();
                String b = AGE.getText().toString();
                String c = NATIONALITY.getText().toString();
                String aa = dg.getText().toString();
                String bb = eng.getText().toString();
                String cc = sci.getText().toString();
                String dd = art.getText().toString();
                String ee = bus.getText().toString();
                String ff = la.getText().toString();

                Intent n = new Intent(MajorActivity.this, PrintActivity.class);

                n.putExtra("NAME",a);
                n.putExtra("AGE",b);
                n.putExtra("NATIONALITY",c);
                n.putExtra("degree",aa);
                n.putExtra("eng",bb);
                n.putExtra("sci",cc);
                n.putExtra("art",dd);
                n.putExtra("bus",ee);
                n.putExtra("la",ff);

                startActivity(n);

            }
        });

    }

    public static final int GET_FROM_GALLERY = 3;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);



        if(requestCode==GET_FROM_GALLERY && resultCode == Activity.RESULT_OK) {
            Uri selectedImage = data.getData();
            Bitmap bitmap = null;
            try {
                bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);
            } catch (FileNotFoundException e) {

                e.printStackTrace();
            } catch (IOException e) {

                e.printStackTrace();
            }
        }
    }
}