package com.example.supercv;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.io.FileNotFoundException;
import java.io.IOException;

public class PrintActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_print);

        ImageView profile = findViewById(R.id.profile);
        TextView degree = findViewById(R.id.Degree);
        TextView degree2 = findViewById(R.id.Degree2);
        TextView degree3 = findViewById(R.id.Degree3);
        TextView degree4 = findViewById(R.id.Degree4);
        TextView degree5 = findViewById(R.id.Degree5);
        TextView degree6 = findViewById(R.id.Degree6);


        TextView name = findViewById(R.id.name);
        TextView age = findViewById(R.id.age);
        TextView nationality = findViewById(R.id.nationality);


        Bundle S = getIntent().getExtras();
        String A = S.getString("NAME");
        String B = S.getString("AGE");
        String C = S.getString("NATIONALITY");
        String AA = S.getString("degree");
        String BB = S.getString("eng");
        String CC = S.getString("sci");
        String DD = S.getString("art");
        String EE = S.getString("bus");
        String FF = S.getString("la");

        name.setText(A);
        age.setText(B);
        nationality.setText(C);
        degree.setText(AA);
        degree2.setText(BB);
        degree3.setText(CC);
        degree4.setText(DD);
        degree5.setText(EE);
        degree6.setText(FF);


    }

    public static final int GET_FROM_GALLERY = 3;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (requestCode == GET_FROM_GALLERY && resultCode == Activity.RESULT_OK) {
            Uri selectedImage = data.getData();
            Bitmap bitmap = null;
            try {
                bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);
            } catch (FileNotFoundException e) {

                e.printStackTrace();
            } catch (IOException e) {

                e.printStackTrace();
            }
        }
    }
}