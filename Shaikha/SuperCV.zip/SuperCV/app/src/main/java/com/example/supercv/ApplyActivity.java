package com.example.supercv;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class ApplyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apply2);

        final TextView ME =findViewById(R.id.textView21);
        final TextView EG =findViewById(R.id.textView22);
        final TextView SC =findViewById(R.id.textView23);
        final TextView AR =findViewById(R.id.textView24);
        final TextView BU =findViewById(R.id.textView25);
        final TextView LA =findViewById(R.id.textView26);

        Button me = findViewById(R.id.button4);
        Button eg = findViewById(R.id.button5);
        Button sc = findViewById(R.id.button6);
        Button ar = findViewById(R.id.button7);
        Button bu = findViewById(R.id.button8);
        Button la = findViewById(R.id.button9);

        me.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String a = ME.getText().toString();

                Intent X = new Intent(ApplyActivity.this , MajorActivity.class);

                X.putExtra("degree",a);

                startActivity(X);
            }
        });

        eg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String b = EG.getText().toString();

                Intent Y = new Intent(ApplyActivity.this , MajorActivity.class);

                Y.putExtra("eng",b);

                startActivity(Y);


            }
        });

        sc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String c = SC.getText().toString();

                Intent Z = new Intent(ApplyActivity.this , MajorActivity.class);

                Z.putExtra("sci",c);

                startActivity(Z);

            }
        });

        ar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String d = AR.getText().toString();

                Intent XX = new Intent(ApplyActivity.this , MajorActivity.class);

                XX.putExtra("art",d);

                startActivity(XX);

            }
        });

        bu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String e = BU.getText().toString();

                Intent YY = new Intent(ApplyActivity.this , MajorActivity.class);

                YY.putExtra("bus",e);

                startActivity(YY);

            }
        });

        la.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String f = LA.getText().toString();

                Intent ZZ = new Intent(ApplyActivity.this , MajorActivity.class);

                ZZ.putExtra("la",f);

                startActivity(ZZ);


            }
        });



    }
}