package com.example.supercv;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button A = findViewById(R.id.button);
        Button AB = findViewById(R.id.button2);
        Button C = findViewById(R.id.button3);

        A.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a = new Intent(MainActivity.this , ApplyActivity.class);
                startActivity(a);
            }
        });

        AB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ab = new Intent(MainActivity.this , AboutUsActivity.class);
                startActivity(ab);
            }
        });

        C.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent c = new Intent(MainActivity.this , ContactUsActivity.class);
        startActivity(c);
    }
});

    }
}