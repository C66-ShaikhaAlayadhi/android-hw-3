package com.example.supercv;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;

public class ContactUsActivity extends AppCompatActivity implements LocationListener {

    Button button_location;
    TextView textView5;
    LocationManager locationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_us2);


        textView5 = findViewById(R.id.textView5);
        button_location = findViewById(R.id.button_location);
        final TextView NA = findViewById(R.id.textView15);
        final TextView NA2 = findViewById(R.id.textView16);

        ImageButton Call= findViewById(R.id.imageButton);
        ImageButton Email= findViewById(R.id.imageButton2);

        Call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String No = NA.getText().toString();
                String No2 =NA2.getText().toString();
                Uri number = Uri.parse("tel:"+No);
                Intent Z = new Intent(Intent.ACTION_DIAL, number);
                startActivity(Z);
            }
        });


        Email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Y = new Intent(Intent.ACTION_VIEW);
                Y.setData(Uri.parse("abc@gmail.com"));
                Y.setClassName("com.google.android.gm", "com.google.android.gm.ComposeActivityGmail");
                Y.putExtra(Intent.EXTRA_CC, new String[]{"xyz@gmail.com"});
                Y.putExtra(Intent.EXTRA_BCC, new String[]{"pqr@gmail.com"});
                Y.putExtra(Intent.EXTRA_SUBJECT, "your subject goes here...");
                Y.putExtra(Intent.EXTRA_TEXT, "Your message content goes here...");

                startActivity(Y);
            }
        });


        if (ContextCompat.checkSelfPermission(ContactUsActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)
        != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(ContactUsActivity.this, new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION
            },100);
        }



        button_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getLocation();
            }
        });





    }

    @SuppressLint("MissingPermission")
    private void getLocation() {

        try {
            locationManager = (LocationManager) getApplicationContext().getSystemService(LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,5000,5,ContactUsActivity.this);

        }catch (Exception e){
            e.printStackTrace();
        }


    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        Toast.makeText(this,""+location.getLatitude()+","+location.getLongitude(), Toast.LENGTH_SHORT).show();

        try {
            Geocoder geocoder = new Geocoder(ContactUsActivity.this, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(location.getLatitude(),location.getLongitude(),1);
            String address = addresses.get(0).getAddressLine(0);

            textView5.setText(address);

        }catch (Exception e){
            e.printStackTrace();
        }


    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(@NonNull String provider) {

    }

    @Override
    public void onProviderDisabled(@NonNull String provider) {

    }
}